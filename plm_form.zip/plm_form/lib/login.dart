import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'authservice.dart';
import 'Tabs.dart';



class LoginScreen extends StatefulWidget {
  LoginScreen({this.auth});
  final BaseAuth auth;
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  void initState() {
    super.initState();
  }

  final _formkey = GlobalKey<FormState>();

  TextEditingController _userController = TextEditingController();

  TextEditingController _passwordcontroller = TextEditingController();

  @override
  void dispose() {
    _userController.dispose();

    _passwordcontroller.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.orange,
        title: Text('Login Page'),
      ),
      body: Padding(
        padding: const EdgeInsets.only(top: 80.0),
        child: Center(
          child: Container(
            padding: EdgeInsets.all(16),
            child: Column(
              children: <Widget>[
                CircleAvatar(
                  radius: 75,
                  backgroundColor: Colors.orange,
                  child: Icon(
                    Icons.account_circle,
                    size: 150,
                    color: Colors.white,
                  ),
                ),
                Form(
                    key: _formkey,
                    child: Column(
                      children: <Widget>[
                        TextFormField(
                          controller: _userController,
                          decoration: InputDecoration(
                              hintText: 'E-mail', icon: Icon(Icons.email)),
                          validator: (value) {
                            if (value.isEmpty) {
                              return 'Please E-mail is required';
                            }
                            return null;
                          },
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        TextFormField(
                          controller: _passwordcontroller,
                          decoration: InputDecoration(
                              hintText: 'Password', icon: Icon(Icons.vpn_key)),
                          validator: (value) {
                            if (value.isEmpty) {
                              return 'Please Password  is required';
                            }
                            return null;
                          },
                        ),
                        SizedBox(
                          height: 25,
                        ),
                        RaisedButton(
                          color: Colors.orange,
                          child: Text(
                            'Login',
                            style: TextStyle(color: Colors.white),
                          ),
                          onPressed: () async {
                            if (_formkey.currentState.validate()) {
                              try {
                                FirebaseUser user = (await FirebaseAuth.instance
                                        .signInWithEmailAndPassword(
                                            email: _userController.text,
                                            password: _passwordcontroller.text))
                                    as FirebaseUser;
                                print('Signed in : ${user.uid}');
                                Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => TabsExample()));
                              } catch (e) {
                                print('Error : $e');
                                // Navigator.of(context).pushReplacementNamed('/Tabs');
                              }
                            }
                          },
                        ),
                      ],
                    )),
              ],
            ),
          ),
        ),
      ),
    );



  }
}
