class TeamName{
  int id;
  String name;
  TeamName({this.id,this.name});
  factory TeamName.fromJson(Map<String, dynamic> parsedJson){
    return TeamName(
      id:parsedJson["id"],
      name: parsedJson["name"] as String,
    );
  }
}