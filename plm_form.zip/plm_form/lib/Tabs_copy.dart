
import 'package:flutter_rounded_date_picker/rounded_picker.dart';
import 'authservice.dart';
import 'dart:core';
import 'package:firebase_database/firebase_database.dart';
import 'package:http/http.dart' as http;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:searchable_dropdown/searchable_dropdown.dart';
import 'multiSelect.dart';

class TabsExample extends StatefulWidget {
  TabsExample({Key key, this.auth, this.userId, this.logoutCallback})
      : super(key: key);

  final BaseAuth auth;
  final VoidCallback logoutCallback;
  final String userId;

  //TabsExample({Key key}) : super(key: key);
  @override
  State<StatefulWidget> createState() {
    return new TabsExampleState();
  }
}

class TabsExampleState extends State<TabsExample> {
  bool _gen1SerialE = true;
  bool _gen1RHoursE = true;
  bool _gen2SerialE = false;
  bool _gen2RHoursE = false;
  bool _gen1Oil = true;
  bool _gen2Oil = false;
  bool _gen1notes = true;
  bool _gen2notes = false;
  List _myActivities;
  var checkoilOK = "OK";
  var checkoilNok = "NOK";
  var checkWaterOK = "OK";
  var checkWaterNok = "NOK";
  var checkFuelOK = "OK";
  var checkFuelNok = "NOK";
  var checkoilOK2 = "OK";
  var checkoilNok2 = "NOK";
  var checkWaterOK2 = "OK";
  var checkWaterNok2 = "NOK";
  var checkFuelOK2 = "OK";
  var checkFuelNok2 = "NOK";
  var _gen1Oileak;
  var _gen1Waterleak;
  var _gen1Fuelleak;
  var _gen2Oileak;
  var _gen2Waterleak;
  var _gen2Fuelleak;
  var AtsStatus;
  var AtsMStatus;
  var MdbMStatus;
  var MdbStatus;
  var fuelTankStatus;
  var SiteClean;
  var BtsClean;
  var ACStatus;
  var SPUsedStatus;
  bool isEnabled = true;
  bool isEnabled2 = false;
  bool isEnabledM = false;
  bool isEnabledA = false;
  var phaseType;
  var CpType;

  var _firebaseRef = FirebaseDatabase().reference().child('Data');

  static var selectedSiteCode;

  var selectedSiteType;

  var selectedMDBM;
  var selectedATSM;
  var selectedFuelM;
  bool atsch = true;
  bool mdbsch = true;
  bool fuelch = true;

  var selectedTeam;
  List selectedTeamArray = [];
  List selectedMUsedArray = [];
  List selectedMDBArray = [];
  List selectedATSArray = [];
  List selectedFuelArray = [];

  List list1 = [];

  bool ignore = false;

  List SelectedMdbArray = [];

  List SelectedAtsArray = [];

  get value => null;

  signOut() async {
    try {
      await widget.auth.signOut();
      widget.logoutCallback();
    } catch (e) {
      print(e);
    }
  }

  DateTime selectedDate = DateTime.now();
  final now = DateTime.now();
  DateFormat dateFormat = DateFormat("EEEE, MMMM d, yyyy ");
  DateFormat timeFormat = DateFormat("h:mm a");

  TimeOfDay time;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  var databaseReference = Firestore.instance;

  TextEditingController _Location = new TextEditingController();
  TextEditingController _FuleLevel = new TextEditingController();
  TextEditingController _Gen1Serial = new TextEditingController();
  TextEditingController _Gen2Serial = new TextEditingController();
  TextEditingController _Gen1RHours = new TextEditingController();
  TextEditingController _Gen2RHours = new TextEditingController();
  TextEditingController _Oil1add = new TextEditingController();
  TextEditingController _Oil2add = new TextEditingController();
  TextEditingController _FuelTankSize = new TextEditingController();
  TextEditingController _Commercialpower = new TextEditingController();
  TextEditingController _Notes = new TextEditingController();
  TextEditingController _Gen1notes = new TextEditingController();
  TextEditingController _Gen2notes = new TextEditingController();
  TextEditingController _AmpExceding = new TextEditingController();

  List checked36 = [];
  List checked7 = [];

  bool textFieldEnable = true;

  var dateDb;
  var _timeIn;

  var _timeOut;

  sendMessage() {
    List newArr = [];
    var i;
    for (i = 0; i < selectedTeam.length; i++) {
      newArr.add(selectedTeamArray[selectedTeam[i]]);
    }
    List MdbArr = [];
    var j;
    for (j = 0; j < selectedMDBM.length; j++) {
      MdbArr.add(selectedMDBArray[selectedMDBM[j]]);
    }
    List ATSArr = [];
    var k;
    for (k = 0; k < selectedMDBM.length; k++) {
      ATSArr.add(selectedATSArray[selectedMDBM[j]]);
    }
    List FeulArr = [];
    var l;
    for (l = 0; l < selectedMDBM.length; l++) {
      FeulArr.add(selectedFuelArray[selectedMDBM[j]]);
    }

    _firebaseRef.push().set({
      "SiteCode": selectedSiteCode.toString(),
      "SiteType": selectedSiteType.toString(),
      "Date": dateDb.toString(),
      "Location": _Location.text,
      "TimeIn": _timeIn.toString(),
      "TimeOut": _timeOut.toString(),
      "PowerSource": checked.toString(),
      "Commercial power": _Commercialpower.text,
      "Connection Type": CpType.toString(),
      "Phase Type": phaseType.toString(),
      "Gen1Serial": _Gen1Serial.text,
      "Gen1RHours": _Gen1RHours.text,
      "Gen1": selectedGen1tList.toString(),
      "Oil Added Gen1": _Oil1add.text,
      "Oli Leakage Gen1": _gen1Oileak.toString(),
      "Water Leakage Gen1": _gen1Waterleak.toString(),
      "Fuel Leakage Gen1": _gen1Fuelleak.toString(),
      "Gen1 Notes": _Gen1notes.text,
      "Gen2Serial": _Gen2Serial.text,
      "Gen2RHours": _Gen2RHours.text,
      "Gen2": selectedGen2tList.toString(),
      "Oil Added Gen2": _Oil2add.text,
      "Oli Leakage Gen2": _gen2Oileak.toString(),
      "Water Leakage Gen2": _gen2Waterleak.toString(),
      "Fuel Leakage Gen2": _gen2Fuelleak.toString(),
      "Gen1 Notes": _Gen2notes.text,
      "ATS board Status": AtsStatus.toString(),
      "ATS board Matrials": AtsMStatus.toString(),
      "ATS board Matrials Used": ATSArr.toString(),
      "MDB board Status": MdbStatus.toString(),
      "MDB board Matrials": MdbMStatus.toString(),
      "MDB board Matrials Used ": MdbArr.toString(),
      "Fuel Matrials Used": FeulArr.toString(),
      "Ampeer Exceeding": _AmpExceding.text,
      "Fuel Tank Status": fuelTankStatus.toString(),
      "FuelLevel": _FuleLevel.text,
      "Fuel Tank Size": _FuelTankSize.text,
      "Site Clean": SiteClean.toString(),
      "BTS Fan Clean": BtsClean.toString(),
      "AC Status": ACStatus.toString(),
      "SPUsed Status": SPUsedStatus.toString(),
      "Site Owner": checked36.toString(),
      "Team Members": newArr.toString(),
      "Notes": _Notes.text,
    }).whenComplete(() => () {
          ///when done all of these call this function
          ///mmm other solution
          ///check all properties in firebase is existes or not by
          ///if(proberty.exsist==true)
          ///do this to all proberty
          ///or use this function lool
        });
  }

  checkNull() {
    final FormState form = _formKey.currentState;

    if (form.validate()&&
        AtsStatus == null &&
        MdbStatus == null &&
        fuelTankStatus == null &&
        SiteClean == null &&
        BtsClean == null &&
        ACStatus == null &&
        SPUsedStatus == null &&
        _gen1Oileak == null &&
        _gen2Oileak == null &&
        _gen1Waterleak == null &&
        _gen2Waterleak == null &&
        _gen1Fuelleak == null &&
        _gen2Fuelleak == null) {
      showDialog(
          context: context,
          builder: (BuildContext context) {
            return Dialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20.0)),
              //this right here
              child: Container(
                height: 200,
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextField(
                        decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: 'Did you fill out all the fields ?'),
                      ),
                      Center(
                        child: SizedBox(
                          width: 100.0,
                          child: RaisedButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            child: Text(
                              "Close",
                              style: TextStyle(color: Colors.white),
                            ),
                            color: Colors.orange,
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            );
          });
    } else {
      sendMessage();

    }
  }

  static bool test1 = false;
  static bool test2 = false;
  static bool test3 = false;
  static bool test4 = false;
  void check() {
    bool enable1, enable2, enable3, enable4;
    enable1 = test1;
    enable2 = test2;
    enable3 = test3;
    enable4 = test4;

    if (enable2 == true) {
      _gen1SerialE = true;
      _gen1RHoursE = true;
      _gen1Oil = true;
      _gen1notes = true;
      checkoilOK = "OK";
      checkoilNok = "NOK";
      checkWaterOK = "OK";
      checkWaterNok = "NOK";
      checkFuelOK = "OK";
      checkFuelNok = "NOK";
      isEnabled = true;
      /////////////
      _gen2SerialE = true;
      _gen2RHoursE = true;
      _gen2Oil = true;
      _gen2notes = true;
      isEnabled2 = true;
      checkoilOK = "OK";
      checkoilNok = "NOK";
      checkoilOK2 = "OK";
      checkoilNok2 = "NOK";
      checkWaterOK2 = "OK";
      checkWaterNok2 = "NOK";
      checkFuelOK2 = "OK";
      checkFuelNok2 = "NOK";
    } else {
      _gen2SerialE = false;
      _gen2RHoursE = false;
      _gen2Oil = false;
      _gen2notes = false;
      checkoilOK2 = null;
      checkoilNok2 = null;
      checkWaterOK2 = null;
      checkWaterNok2 = null;
      checkFuelOK2 = null;
      checkFuelNok2 = null;
      isEnabled2 = false;
    }
    if (enable1 == true && enable2 == false) {
      _gen2SerialE = false;
      _gen2RHoursE = false;
      _gen2Oil = false;
      _gen2notes = false;
      checkoilOK2 = null;
      checkoilNok2 = null;
      checkWaterOK2 = null;
      checkWaterNok2 = null;
      checkFuelOK2 = null;
      checkFuelNok2 = null;
      isEnabled2 = false;
    } else {
      _gen2SerialE = true;
      _gen2RHoursE = true;
      _gen2Oil = true;
      _gen2notes = true;
      isEnabled2 = true;
      checkoilOK = "OK";
      checkoilNok = "NOK";
      checkoilOK2 = "OK";
      checkoilNok2 = "NOK";
      checkWaterOK2 = "OK";
      checkWaterNok2 = "NOK";
      checkFuelOK2 = "OK";
      checkFuelNok2 = "NOK";
    }
    if (enable3 == true && enable1 == false && enable2 == false) {
      _gen1SerialE = false;
      _gen1RHoursE = false;
      _gen1Oil = false;
      _gen1notes = false;
      checkoilOK = null;
      checkoilNok = null;
      checkWaterOK = null;
      checkWaterNok = null;
      checkFuelOK = null;
      checkFuelNok = null;
      isEnabled = false;
//اكستيرنل بدون مولدات
      _gen2SerialE = false;
      _gen2RHoursE = false;
      _gen2Oil = false;
      _gen2notes = false;
      checkoilOK2 = null;
      checkoilNok2 = null;
      checkWaterOK2 = null;
      checkWaterNok2 = null;
      checkFuelOK2 = null;
      checkFuelNok2 = null;
      isEnabled2 = false;
    } else if (enable3 == true && enable1 == true && enable2 == false) {
      _gen1SerialE = true;
      _gen1RHoursE = true;
      _gen1Oil = true;
      _gen1notes = true;
      checkoilOK = "OK";
      checkoilNok = "NOK";
      checkWaterOK = "OK";
      checkWaterNok = "NOK";
      checkFuelOK = "OK";
      checkFuelNok = "NOK";
      isEnabled = true;
//اكستيرنل ومولدةوحده
      _gen2SerialE = false;
      _gen2RHoursE = false;
      _gen2Oil = false;
      _gen2notes = false;
      checkoilOK2 = null;
      checkoilNok2 = null;
      checkWaterOK2 = null;
      checkWaterNok2 = null;
      checkFuelOK2 = null;
      checkFuelNok2 = null;
      isEnabled2 = false;
    } else if (enable3 == true && enable1 == true && enable2 == true) {
      _gen1SerialE = true;
      _gen1RHoursE = true;
      _gen1Oil = true;
      _gen1notes = true;
      checkoilOK = "OK";
      checkoilNok = "NOK";
      checkWaterOK = "OK";
      checkWaterNok = "NOK";
      checkFuelOK = "OK";
      checkFuelNok = "NOK";
      isEnabled = true;
//اكستيرنل ومولدتين
      _gen2SerialE = true;
      _gen2RHoursE = true;
      _gen2Oil = true;
      _gen2notes = true;
      checkoilOK2 = "OK";
      checkoilNok2 = "NOK";
      checkWaterOK2 = "OK";
      checkWaterNok2 = "NOK";
      checkFuelOK2 = "OK";
      checkFuelNok2 = "NOK";
      isEnabled2 = true;
    } else {
      _gen1SerialE = true;
      _gen1RHoursE = true;
      _gen1Oil = true;
      _gen1notes = true;
      checkoilOK = "OK";
      checkoilNok = "NOK";
      checkWaterOK = "OK";
      checkWaterNok = "NOK";
      checkFuelOK = "OK";
      checkFuelNok = "NOK";
      isEnabled = true;
//اكستيرنل بدون مولدات
      _gen2SerialE = true;
      _gen2RHoursE = true;
      _gen2Oil = true;
      _gen2notes = true;
      checkoilOK2 = "OK";
      checkoilNok2 = "NOK";
      checkWaterOK2 = "OK";
      checkWaterNok2 = "NOK";
      checkFuelOK2 = "OK";
      checkFuelNok2 = "NOK";
      isEnabled2 = true;
    }
  }

  List<bool> checked = [test1, test2, test3, test4];

  List<String> gentList = [
    "Oil",
    "Oil Filter",
    "Fuel Filter",
    "LiftPump Filter",
    "Air Filter",
    "Clean"
  ];
  List<String> gen2List = [
    "Oil",
    "Oil Filter",
    "Fuel Filter",
    "LiftPump Filter",
    "Air Filter",
    "Clean"
  ];

  List<String> selectedGen1tList = List();

  _showReportDialog() {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          //Here we will build the content of the dialog
          return AlertDialog(
            title: Text(" Gen.1 / المولدة الأولى :"),
            content: MultiSelectChip(
              gentList,
              onSelectionChanged: (selectedList) {
                setState(() {
                  selectedGen1tList = selectedList;
                });
              },
            ),
            actions: <Widget>[
              FlatButton(
                child: Text("Save"),
                onPressed: () => Navigator.of(context).pop(),
              )
            ],
          );
        });
  }

  List<String> selectedGen2tList = List();

  _showReportDialog2() {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          //Here we will build the content of the dialog
          return AlertDialog(
            title: Text(" Gen.2 / المولدة الثانية :"),
            content: MultiSelectChip(
              gen2List,
              onSelectionChanged: (selectedList) {
                setState(() {
                  selectedGen2tList = selectedList;
                });
              },
            ),
            actions: <Widget>[
              FlatButton(
                child: Text("Save"),
                onPressed: () => Navigator.of(context).pop(),
              )
            ],
          );
        });
  }

  void _onFormSaved() {
    final FormState form = _formKey.currentState;
    form.save();
  }

  @override
  Widget build(BuildContext context) {
    final _kTabPages = <Widget>[
      Container(
        padding: EdgeInsets.all(20.0),
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: new Column(
              children: <Widget>[
                StreamBuilder<QuerySnapshot>(
                    stream:
                        Firestore.instance.collection("SiteCode").snapshots(),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) {
                        Text("Loding...");
                      } else {
                        List<DropdownMenuItem> sitecode = [];
                        for (int i = 0;
                            i < snapshot.data.documents.length;
                            i++) {
                          DocumentSnapshot snap = snapshot.data.documents[i];
                          sitecode.add(DropdownMenuItem(
                            child: Text(snap.documentID),
                            value: "${snap.documentID}",
                          ));
                        }
                        return Container(
                          child: Column(
                            children: <Widget>[
                              SearchableDropdown.single(
                                items: sitecode
                                  ..map((sitecode) {
                                    return (DropdownMenuItem(
                                        child: Text('testItems'),
                                        value: sitecode));
                                  }).toList(),
                                value: selectedSiteCode,
                                hint: "1. Select Site Code:",
                                searchHint: "Select Site Code",
                                onChanged: (itemsValue) {
                                  setState(() {
                                    selectedSiteCode = itemsValue;
                                  });
                                },
                                isExpanded: true,
                              ),
                            ],
                          ),
                        );
                      }
                      return Container();
                    }),
                StreamBuilder<QuerySnapshot>(
                    stream:
                        Firestore.instance.collection("SiteType").snapshots(),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) {
                        Text("Loding...");
                      } else {
                        List<DropdownMenuItem> sitetype = [];
                        for (int i = 0;
                            i < snapshot.data.documents.length;
                            i++) {
                          DocumentSnapshot snap = snapshot.data.documents[i];
                          sitetype.add(DropdownMenuItem(
                            child: Text(snap.documentID),
                            value: "${snap.documentID}",
                          ));
                        }
                        return Container(
                          child: Column(
                            children: <Widget>[
                              SearchableDropdown.single(
                                items: sitetype
                                  ..map((sitetype) {
                                    return (DropdownMenuItem(
                                        child: Text('testItems'),
                                        value: sitetype));
                                  }).toList(),
                                value: selectedSiteType,
                                hint: "2. Select Site Type:",
                                searchHint: "Select Site Type",
                                onChanged: (itemsValue) {
                                  setState(() {
                                    selectedSiteType = itemsValue;
                                  });
                                },
                                isExpanded: true,
                              ),
                            ],
                          ),
                        );
                      }
                      return Container();
                    }),
                Padding(
                  padding: const EdgeInsets.only(top: 10.0, bottom: 6.0),
                  child: Row(
                    children: <Widget>[
                      new Text('3.Date / التاريخ : '),
                      new Text(
                        "*",
                        style: TextStyle(color: Colors.red),
                      ),
                      new IconButton(
                        icon: new Icon(
                          Icons.date_range,
                          color: Colors.orange,
                          size: 25,
                        ),
                        onPressed: () {
                          showRoundedDatePicker(
                                  context: context,
                                  theme: ThemeData(primaryColor: Colors.orange),
                                  borderRadius: 10,
                                  initialDate: DateTime.now(),
                                  firstDate: DateTime(2000),
                                  lastDate: DateTime(2030))
                              .then((date) {
                            setState(() {
                              dateDb = date;
                            });
                          });
                        },
                      )
                    ],
                  ),
                ),
                new TextFormField(
                  controller: _Location,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    labelText: '4. Location / الموقع:',
                    hintText: 'Enter Your Answer',
                  ),
                ),
                new Row(
                  children: <Widget>[
                    new Text('5. TimeIn / وقت الدخول : '),
                    new Text(
                      "    *",
                      style: TextStyle(color: Colors.red),
                    ),
                    new IconButton(
                      icon: new Icon(
                        Icons.timer,
                        color: Colors.orange,
                      ),
                      onPressed: () {
                        showRoundedTimePicker(
                          context: context,
                          theme: ThemeData(primaryColor: Colors.orange),
                          initialTime:
                              TimeOfDay(hour: now.hour, minute: now.minute),
                        ).then((time) {
                          setState(() {
                            _timeIn = time;
                          });
                        });
                      },
                    )
                  ],
                ),
                new Row(
                  children: <Widget>[
                    new Text('6.TimeOut / وقت الخروج : '),
                    new Text(
                      " *",
                      style: TextStyle(color: Colors.red),
                    ),
                    Theme(
                        data: ThemeData(primaryColor: Colors.orange),
                        child: new IconButton(
                          icon: new Icon(
                            Icons.timer,
                            color: Colors.orange,
                          ),
                          onPressed: () {
                            showRoundedTimePicker(
                              context: context,
                              theme: ThemeData(primaryColor: Colors.orange),
                              initialTime:
                                  TimeOfDay(hour: now.hour, minute: now.minute),
                            ).then((time) {
                              setState(() {
                                _timeOut = time;
                              });
                            });
                          },
                        )),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 10.0),
                  child: new Column(
                    children: <Widget>[
                      new Row(
                        children: <Widget>[
                          new Text("7. Power Source / مصدر الطاقة:"),
                          new Text(
                            "*",
                            style: TextStyle(color: Colors.red),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Column(
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Checkbox(
                          tristate: false,
                          value: test1,
                          onChanged: (bool value1) {
                            setState(() {
                              test1 = value1;
                              check();
                            });
                          },
                        ),
                        Text('1 Gen.'),
                      ],
                    ),
                    Row(
                      children: <Widget>[
                        Checkbox(
                          tristate: false,
                          value: test2,
                          onChanged: (bool value2) {
                            setState(() {
                              test2 = value2;
                              check();
                            });
                          },
                        ),
                        Text('2 Gen.'),
                      ],
                    ),
                    Row(
                      children: <Widget>[
                        Checkbox(
                          tristate: false,
                          value: test3,
                          onChanged: (bool value3) {
                            setState(() {
                              test3 = value3;
                              check();
                            });
                          },
                        ),
                        Text('External'),
                      ],
                    ),
                    Row(
                      children: <Widget>[
                        Checkbox(
                          tristate: false,
                          value: test4,
                          onChanged: (bool value4) {
                            setState(() {
                              test4 = value4;
                              check();
                            });
                          },
                        ),
                        Text('C.P'),
                      ],
                    ),
                  ],
                ),
                new TextFormField(
                  controller: _Commercialpower,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    labelText:
                        '8.Commercial power counter readings / قرائة عداد الوطنية:',
                    hintText: 'enter Your Answer ',
                  ),
                  validator: (value) {
                    if (value.isEmpty) {
                      return 'Please Fill Required field';
                    }
                  },
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 20.0),
                  child: new Row(
                    children: <Widget>[
                      new Text("9. C.P connection type :"),
                    ],
                  ),
                ),
                Column(
                  children: <Widget>[
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('Governmental connection'),
                      value: "Governmental connection",
                      groupValue: CpType,
                      onChanged: (value) {
                        setState(() {
                          CpType = value;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('from Owner'),
                      value: "from Owner",
                      groupValue: CpType,
                      onChanged: (value) {
                        setState(() {
                          CpType = value;
                        });
                      },
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 20.0),
                  child: new Row(
                    children: <Widget>[
                      new Text("10. Phase type :"),
                      new Text(
                        "*",
                        style: TextStyle(color: Colors.red),
                      )
                    ],
                  ),
                ),
                Column(
                  children: <Widget>[
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('Single Phase'),
                      value: "Single Phase",
                      groupValue: phaseType,
                      onChanged: (value) {
                        setState(() {
                          phaseType = value;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('Three Phase'),
                      value: "Three Phase",
                      groupValue: phaseType,
                      onChanged: (value) {
                        setState(() {
                          phaseType = value;
                        });
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
      Container(
        padding: EdgeInsets.all(20.0),
        child: SingleChildScrollView(
          child: Form(
            // key: _formkey,
            child: new Column(
              children: <Widget>[
                new TextFormField(
                  enabled: _gen1SerialE,
                  controller: _Gen1Serial,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    labelText:
                        '11. Gen. 1 Serial  الرقم التسلسلي للمولدة الأولى ',
                    hintText: 'enter Your Answer',
                  ),
                ),
                new TextFormField(
                  enabled: _gen1RHoursE,
                  controller: _Gen1RHours,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    labelText: '12. Gen. 1 R. Hours عداد المولدة الأولى ',
                    hintText: 'enter Your Answer',
                  ),
                  validator: (value) {
                    if (value.isEmpty) {
                      return 'Please Fill Required field';
                    }
                  },
                ),
                Row(
                  children: <Widget>[
                    Text('13. Gen.1 / المولدة الأولى :'),
                    Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: ButtonTheme(
                        minWidth: 30.0,
                        height: 20.0,
                        child: RaisedButton(
                          color: Colors.orange,
                          disabledColor: Colors.grey,
                          child: Text("Select"),
                          onPressed:
                              isEnabled ? () => _showReportDialog2() : null,
                        ),
                      ),
                    ),
                  ],
                ),
                new TextFormField(
                  controller: _Oil1add,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    labelText:
                        '14. Gen 1 Oil(Added or Replaced)/ المولدة الاولى-الدهن (المضاف او المستبدل:',
                    hintText: 'Enter Your Answer',
                  ),
                ),
                new Row(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Column(
                        children: <Widget>[
                          new Text("15.Gen 1 - Check Oil Leakage"),
                          new Text(" المولدة الاولى - فحص نضوح دهن:"),
                        ],
                      ),
                    )
                  ],
                ),
                Column(
                  children: <Widget>[
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('OK'),
                      value: checkoilOK,
                      groupValue: _gen1Oileak,
                      onChanged: (value) {
                        setState(() {
                          _gen1Oileak = value;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('NOK'),
                      value: checkoilNok,
                      groupValue: _gen1Oileak,
                      onChanged: (value) {
                        setState(() {
                          _gen1Oileak = value;
                        });
                      },
                    ),
                  ],
                ),
                new Row(
                  children: <Widget>[
                    Column(
                      children: <Widget>[
                        new Text("16.Gen 1 - Check Water Leakage "),
                        new Text(" المولدة الاولى - فحص نضوح الماء:"),
                      ],
                    ),
                  ],
                ),
                Column(
                  children: <Widget>[
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('OK'),
                      value: checkWaterOK,
                      groupValue: _gen1Waterleak,
                      onChanged: (value) {
                        setState(() {
                          _gen1Waterleak = value;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('NOK'),
                      value: checkWaterNok,
                      groupValue: _gen1Waterleak,
                      onChanged: (value) {
                        setState(() {
                          _gen1Waterleak = value;
                        });
                      },
                    ),
                  ],
                ),
                new Row(
                  children: <Widget>[
                    Column(
                      children: <Widget>[
                        new Text("17.Gen 1 - Check Fuel Leakage"),
                        new Text(" : المولدة الاولى - فحص نضوح الكاز"),
                      ],
                    ),
                  ],
                ),
                Column(
                  children: <Widget>[
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('OK'),
                      value: checkFuelOK,
                      groupValue: _gen1Fuelleak,
                      onChanged: (value) {
                        setState(() {
                          _gen1Fuelleak = value;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('NOK'),
                      value: checkFuelNok,
                      groupValue: _gen1Fuelleak,
                      onChanged: (value) {
                        setState(() {
                          _gen1Fuelleak = value;
                        });
                      },
                    ),
                  ],
                ),
                new TextFormField(
                  controller: _Gen1notes,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    labelText:
                        '18.Gen 1-Issues Remarks المولدة الاولى-الملاحظات:',
                    hintText: 'enter Your Answer',
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      Container(
        padding: EdgeInsets.all(20.0),
        child: SingleChildScrollView(
          child: Form(
            //  key: _formkey,
            child: new Column(
              children: <Widget>[
                new TextFormField(
                  enabled: _gen2SerialE,
                  controller: _Gen2Serial,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    labelText:
                        '19. Gen. 2 Serial  الرقم التسلسلي للمولدة الثانية ',
                    hintText: 'enter Your Answer',
                  ),
                ),
                new TextFormField(
                  enabled: _gen2RHoursE,
                  controller: _Gen2RHours,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    labelText: '20. Gen. 2 R. Hours عداد المولدة الثانية ',
                    hintText: 'enter Your Answer',
                  ),
                ),
                Row(
                  children: <Widget>[
                    Text('21. Gen.2 / المولدة الثانية :'),
                    Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: ButtonTheme(
                        minWidth: 30.0,
                        height: 20.0,
                        child: RaisedButton(
                          color: Colors.orange,
                          disabledColor: Colors.grey,
                          child: Text("Select"),
                          onPressed:
                              isEnabled2 ? () => _showReportDialog2() : null,
                        ),
                      ),
                    ),
                  ],
                ),
                new TextFormField(
                  enabled: _gen2Oil,
                  controller: _Oil2add,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    labelText:
                        '22.Gen2 Oil(Added/Replaced)/المولدة الثانية-الدهن (المضاف/المستبدل:',
                    hintText: 'Enter Your Answer',
                  ),
                ),
                new Row(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Column(
                        children: <Widget>[
                          new Text("23.Gen 2-Check Oil Leakage"),
                          new Text(" المولدة الثانية - فحص نضوح دهن:"),
                        ],
                      ),
                    )
                  ],
                ),
                Column(
                  children: <Widget>[
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('OK'),
                      value: checkoilOK2,
                      groupValue: _gen2Oileak,
                      onChanged: (value) {
                        setState(() {
                          _gen2Oileak = value;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('NOK'),
                      value: checkoilNok2,
                      groupValue: _gen2Oileak,
                      onChanged: (value) {
                        setState(() {
                          _gen2Oileak = value;
                        });
                      },
                    ),
                  ],
                ),
                new Row(
                  children: <Widget>[
                    Column(
                      children: <Widget>[
                        new Text("24.Gen 1 - Check Water Leakage "),
                        new Text(" المولدة الاولى - فحص نضوح الماء:"),
                      ],
                    ),
                  ],
                ),
                Column(
                  children: <Widget>[
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('OK'),
                      value: checkWaterOK2,
                      groupValue: _gen2Waterleak,
                      onChanged: (value) {
                        setState(() {
                          _gen2Waterleak = value;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('NOK'),
                      value: checkWaterNok2,
                      groupValue: _gen2Waterleak,
                      onChanged: (value) {
                        setState(() {
                          _gen2Waterleak = value;
                        });
                      },
                    ),
                  ],
                ),
                new Row(
                  children: <Widget>[
                    Column(
                      children: <Widget>[
                        new Text("25.Gen 2- Check Fuel Leakage"),
                        new Text(" : المولدة الثانية - فحص نضوح الكاز"),
                      ],
                    ),
                  ],
                ),
                Column(
                  children: <Widget>[
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('OK'),
                      value: checkFuelOK2,
                      groupValue: _gen2Fuelleak,
                      onChanged: (value) {
                        setState(() {
                          _gen2Fuelleak = value;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('NOK'),
                      value: checkFuelNok2,
                      groupValue: _gen2Fuelleak,
                      onChanged: (value) {
                        setState(() {
                          _gen2Fuelleak = value;
                        });
                      },
                    ),
                  ],
                ),
                new TextFormField(
                  enabled: _gen2notes,
                  controller: _Gen2notes,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    labelText:
                        '26.Gen 2-Issues Remarks المولدة الثانية -الملاحظات:  ',
                    hintText: 'enter Your Answer',
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      Container(
        padding: EdgeInsets.all(20.0),
        child: SingleChildScrollView(
          child: Form(
            // key: _formkey,
            child: new Column(
              children: <Widget>[
                new Row(
                  children: <Widget>[
                    new Text("27.ATS board Status / ATS حالة لوحة ال:"),
                    new Text(
                      "*",
                      style: TextStyle(color: Colors.red),
                    )
                  ],
                ),
                Column(
                  children: <Widget>[
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('OK'),
                      value: "OK",
                      groupValue: AtsStatus,
                      onChanged: (value) {
                        setState(() {
                          AtsStatus = value;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('NOK'),
                      value: "NOK",
                      groupValue: AtsStatus,
                      onChanged: (value) {
                        setState(() {
                          AtsStatus = value;
                        });
                      },
                    ),
                  ],
                ),
                new Row(
                  children: <Widget>[
                    new Text(
                        "28.ATS Materials used / ATS المواد المستخدمه  لل:"),
                    new Text(
                      "*",
                      style: TextStyle(color: Colors.red),
                    )
                  ],
                ),
                Column(
                  children: <Widget>[
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('Yes'),
                      value: "Yes",
                      groupValue: AtsMStatus,
                      onChanged: (value) {
                        setState(() {
                          AtsMStatus = value;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('No'),
                      value: "No",
                      groupValue: AtsMStatus,
                      onChanged: (value) {
                        setState(() {
                          AtsMStatus = value;
                        });
                      },
                    ),
                  ],
                ),
                StreamBuilder<QuerySnapshot>(
                  stream: Firestore.instance.collection("AtsList").snapshots(),
                  builder: (context, snapshot) {
                    if (!snapshot.hasData) {
                      Text("Loding...");
                    } else {
                      List<DropdownMenuItem> ATSItems = [];
                      for (int i = 0; i < snapshot.data.documents.length; i++) {
                        DocumentSnapshot snap = snapshot.data.documents[i];
                        selectedATSArray.add(snap.documentID);
                        ATSItems.add(DropdownMenuItem(
                          child: Text(snap.documentID),
                          value: "${snap.documentID}",
                        ));
                      }

                      return Container(
                        child: Column(
                          children: <Widget>[
                            SearchableDropdown.multiple(
                              items: ATSItems,
                              readOnly: atsch,
                              selectedItems: selectedATSM,
                              hint: Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: Text("Select ATS Matrials Used"),
                              ),
                              searchHint: "Select ATS Matrials Used",
                              onChanged: (value) {
                                setState(() {
                                  selectedATSM = value;
                                });
                              },
                              displayItem: (item, selected) {
                                return (Row(children: [
                                  selected
                                      ? Icon(
                                          Icons.check,
                                          color: Colors.orange,
                                        )
                                      : Icon(
                                          Icons.check_box_outline_blank,
                                          color: Colors.grey,
                                        ),
                                  SizedBox(width: 7),
                                  Expanded(
                                    child: item,
                                  ),
                                ]));
                              },
                              selectedValueWidgetFn: (item) {
                                return (Center(
                                    child: Card(
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          side: BorderSide(
                                            color: Colors.orange,
                                            width: 0.5,
                                          ),
                                        ),
                                        margin: EdgeInsets.all(12),
                                        child: Padding(
                                          padding: const EdgeInsets.all(8),
                                          child: Text(item.toString()),
                                        ))));
                              },
                              doneButton: (selectedItemsDone, doneContext) {
                                return (RaisedButton(
                                    onPressed: () {
                                      Navigator.pop(doneContext);
                                      setState(() {});
                                    },
                                    child: Text("Save")));
                              },
                              closeButton: null,
                              style: TextStyle(fontStyle: FontStyle.italic),
                              searchFn: (String keyword, items) {
                                List<int> ret = List<int>();
                                if (keyword != null &&
                                    items != null &&
                                    keyword.isNotEmpty) {
                                  keyword.split(" ").forEach((k) {
                                    int i = 0;
                                    items.forEach((item) {
                                      if (k.isNotEmpty &&
                                          (item.value
                                              .toString()
                                              .toLowerCase()
                                              .contains(k.toLowerCase()))) {
                                        ret.add(i);
                                      }
                                      i++;
                                    });
                                  });
                                }
                                if (keyword.isEmpty) {
                                  ret = Iterable<int>.generate(items.length)
                                      .toList();
                                }
                                return (ret);
                              },
                              clearIcon: Icon(Icons.delete),
                              icon: Icon(Icons.arrow_drop_down_circle),
                              underline: Container(
                                height: 1.0,
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(
                                            color: Colors.orange, width: 3.0))),
                              ),
                              iconDisabledColor: Colors.red,
                              iconEnabledColor: Colors.orange,
                              isExpanded: true,
                            ),
                          ],
                        ),
                      );
                    }
                    return Container();
                  },
                ),
                new Row(
                  children: <Widget>[
                    new Text("29.MDB board Status / MDB حالة لوحة ال:"),
                    new Text(
                      "*",
                      style: TextStyle(color: Colors.red),
                    )
                  ],
                ),
                Column(
                  children: <Widget>[
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('OK'),
                      value: "OK",
                      groupValue: MdbStatus,
                      onChanged: (value) {
                        setState(() {
                          MdbStatus = value;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('NOK'),
                      value: "NOK",
                      groupValue: MdbStatus,
                      onChanged: (value) {
                        setState(() {
                          MdbStatus = value;
                        });
                      },
                    ),
                  ],
                ),
                new Row(
                  children: <Widget>[
                    new Text(
                        "30.MDB Materials used / MDB المواد المستخدمه  لل:"),
                    new Text(
                      "*",
                      style: TextStyle(color: Colors.red),
                    )
                  ],
                ),
                Column(
                  children: <Widget>[
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('Yes'),
                      value: "Yes",
                      groupValue: MdbStatus,
                      onChanged: (value) {
                        setState(() {
                          MdbStatus = value;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('No'),
                      value: "No",
                      groupValue: MdbStatus,
                      onChanged: (value) {
                        setState(() {
                          MdbStatus = value;
                        });
                      },
                    ),
                  ],
                ),
                StreamBuilder<QuerySnapshot>(
                  stream: Firestore.instance.collection("MdbList").snapshots(),
                  builder: (context, snapshot) {
                    if (!snapshot.hasData) {
                      Text("Loding...");
                    } else {
                      List<DropdownMenuItem> MDBItems = [];
                      for (int i = 0; i < snapshot.data.documents.length; i++) {
                        DocumentSnapshot snap = snapshot.data.documents[i];
                        selectedMDBArray.add(snap.documentID);
                        MDBItems.add(DropdownMenuItem(
                          child: Text(snap.documentID),
                          value: "${snap.documentID}",
                        ));
                      }

                      return Container(
                        child: Column(
                          children: <Widget>[
                            SearchableDropdown.multiple(
                              items: MDBItems,
                              selectedItems: selectedMDBM,
                              hint: Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: Text("Select MDB Matrials Used"),
                              ),
                              searchHint: "Select MDB Matrials Used",
                              onChanged: (value) {
                                setState(() {
                                  selectedMDBM = value;
                                });
                              },
                              displayItem: (item, selected) {
                                return (Row(children: [
                                  selected
                                      ? Icon(
                                          Icons.check,
                                          color: Colors.orange,
                                        )
                                      : Icon(
                                          Icons.check_box_outline_blank,
                                          color: Colors.grey,
                                        ),
                                  SizedBox(width: 7),
                                  Expanded(
                                    child: item,
                                  ),
                                ]));
                              },
                              selectedValueWidgetFn: (item) {
                                return (Center(
                                    child: Card(
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          side: BorderSide(
                                            color: Colors.orange,
                                            width: 0.5,
                                          ),
                                        ),
                                        margin: EdgeInsets.all(12),
                                        child: Padding(
                                          padding: const EdgeInsets.all(8),
                                          child: Text(item.toString()),
                                        ))));
                              },
                              doneButton: (selectedItemsDone, doneContext) {
                                return (RaisedButton(
                                    onPressed: () {
                                      Navigator.pop(doneContext);
                                      setState(() {});
                                    },
                                    child: Text("Save")));
                              },
                              closeButton: null,
                              style: TextStyle(fontStyle: FontStyle.italic),
                              searchFn: (String keyword, items) {
                                List<int> ret = List<int>();
                                if (keyword != null &&
                                    items != null &&
                                    keyword.isNotEmpty) {
                                  keyword.split(" ").forEach((k) {
                                    int i = 0;
                                    items.forEach((item) {
                                      if (k.isNotEmpty &&
                                          (item.value
                                              .toString()
                                              .toLowerCase()
                                              .contains(k.toLowerCase()))) {
                                        ret.add(i);
                                      }
                                      i++;
                                    });
                                  });
                                }
                                if (keyword.isEmpty) {
                                  ret = Iterable<int>.generate(items.length)
                                      .toList();
                                }
                                return (ret);
                              },
                              clearIcon: Icon(Icons.delete),
                              icon: Icon(Icons.arrow_drop_down_circle),
                              underline: Container(
                                height: 1.0,
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(
                                            color: Colors.orange, width: 3.0))),
                              ),
                              iconDisabledColor: Colors.red,
                              iconEnabledColor: Colors.orange,
                              isExpanded: true,
                            ),
                          ],
                        ),
                      );
                    }
                    return Container();
                  },
                ),
                new TextFormField(
                  controller: _AmpExceding,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    labelText:
                        '31. No. Amp. of Power Exceeding / عدد امبيرات التجاوز',
                    hintText: 'enter Your Answer',
                  ),
                ),
                new Row(
                  children: <Widget>[
                    new Text("32. Fuel Tank Status / حالة خزان الوقود:"),
                  ],
                ),
                Column(
                  children: <Widget>[
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('OK'),
                      value: "OK",
                      groupValue: fuelTankStatus,
                      onChanged: (value) {
                        setState(() {
                          fuelTankStatus = value;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('NOK'),
                      value: "NOK",
                      groupValue: fuelTankStatus,
                      onChanged: (value) {
                        setState(() {
                          fuelTankStatus = value;
                        });
                      },
                    ),
                  ],
                ),
                new Row(
                  children: <Widget>[
                    new Text("33.Fuel Tank Materials used/المواد المستخدمه:"),
                    new Text(
                      "*",
                      style: TextStyle(color: Colors.red),
                    )
                  ],
                ),
                Column(
                  children: <Widget>[
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('Yes'),
                      value: "Yes",
                      groupValue: MdbStatus,
                      onChanged: (value) {
                        setState(() {
                          MdbStatus = value;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('No'),
                      value: "No",
                      groupValue: MdbStatus,
                      onChanged: (value) {
                        setState(() {
                          MdbStatus = value;
                        });
                      },
                    ),
                  ],
                ),
                StreamBuilder<QuerySnapshot>(
                  stream: Firestore.instance.collection("FuelList").snapshots(),
                  builder: (context, snapshot) {
                    if (!snapshot.hasData) {
                      Text("Loding...");
                    } else {
                      List<DropdownMenuItem> FuelItems = [];
                      for (int i = 0; i < snapshot.data.documents.length; i++) {
                        DocumentSnapshot snap = snapshot.data.documents[i];
                        selectedFuelArray.add(snap.documentID);
                        FuelItems.add(DropdownMenuItem(
                          child: Text(snap.documentID),
                          value: "${snap.documentID}",
                        ));
                      }

                      return Container(
                        child: Column(
                          children: <Widget>[
                            SearchableDropdown.multiple(
                              items: FuelItems,
                              selectedItems: selectedFuelM,
                              hint: Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: Text("Select Fuel Matrials Used"),
                              ),
                              searchHint: "Select Fuel Matrials Used",
                              onChanged: (value) {
                                setState(() {
                                  selectedFuelM = value;
                                });
                              },
                              displayItem: (item, selected) {
                                return (Row(children: [
                                  selected
                                      ? Icon(
                                          Icons.check,
                                          color: Colors.orange,
                                        )
                                      : Icon(
                                          Icons.check_box_outline_blank,
                                          color: Colors.grey,
                                        ),
                                  SizedBox(width: 7),
                                  Expanded(
                                    child: item,
                                  ),
                                ]));
                              },
                              selectedValueWidgetFn: (item) {
                                return (Center(
                                    child: Card(
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          side: BorderSide(
                                            color: Colors.orange,
                                            width: 0.5,
                                          ),
                                        ),
                                        margin: EdgeInsets.all(12),
                                        child: Padding(
                                          padding: const EdgeInsets.all(8),
                                          child: Text(item.toString()),
                                        ))));
                              },
                              doneButton: (selectedItemsDone, doneContext) {
                                return (RaisedButton(
                                    onPressed: () {
                                      Navigator.pop(doneContext);
                                      setState(() {});
                                    },
                                    child: Text("Save")));
                              },
                              closeButton: null,
                              style: TextStyle(fontStyle: FontStyle.italic),
                              searchFn: (String keyword, items) {
                                List<int> ret = List<int>();
                                if (keyword != null &&
                                    items != null &&
                                    keyword.isNotEmpty) {
                                  keyword.split(" ").forEach((k) {
                                    int i = 0;
                                    items.forEach((item) {
                                      if (k.isNotEmpty &&
                                          (item.value
                                              .toString()
                                              .toLowerCase()
                                              .contains(k.toLowerCase()))) {
                                        ret.add(i);
                                      }
                                      i++;
                                    });
                                  });
                                }
                                if (keyword.isEmpty) {
                                  ret = Iterable<int>.generate(items.length)
                                      .toList();
                                }
                                return (ret);
                              },
                              clearIcon: Icon(Icons.delete),
                              icon: Icon(Icons.arrow_drop_down_circle),
                              underline: Container(
                                height: 1.0,
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(
                                            color: Colors.orange, width: 3.0))),
                              ),
                              iconDisabledColor: Colors.red,
                              iconEnabledColor: Colors.orange,
                              isExpanded: true,
                            ),
                          ],
                        ),
                      );
                    }
                    return Container();
                  },
                ),
                new TextFormField(
                  controller: _FuleLevel,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    labelText:
                        '34. Fuel Level (Ltr|cm) / مستوى الكاز باللتر|سم:',
                    hintText: 'enter Your Answer',
                  ),
                ),
                new TextFormField(
                  controller: _FuelTankSize,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    labelText:
                        '35. Fuel Tank Size (Ltr) / حجم خزان الكاز باللتر:',
                    hintText: 'enter Your Answer',
                  ),
                ),
                new Row(
                  children: <Widget>[
                    new Text("36.Site Clean / تنظيف الموقع:"),
                    new Text(
                      "*",
                      style: TextStyle(color: Colors.red),
                    )
                  ],
                ),
                Column(
                  children: <Widget>[
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('OK'),
                      value: "OK",
                      groupValue: SiteClean,
                      onChanged: (value) {
                        setState(() {
                          SiteClean = value;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('NOK'),
                      value: "NOK",
                      groupValue: SiteClean,
                      onChanged: (value) {
                        setState(() {
                          SiteClean = value;
                        });
                      },
                    ),
                  ],
                ),
                new Row(
                  children: <Widget>[
                    new Text("37. BTS Fan Clean / BTS تنظيف مروحة ال:"),
                  ],
                ),
                Column(
                  children: <Widget>[
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('OK'),
                      value: "OK",
                      groupValue: BtsClean,
                      onChanged: (value) {
                        setState(() {
                          BtsClean = value;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('NOK'),
                      value: "NOK",
                      groupValue: BtsClean,
                      onChanged: (value) {
                        setState(() {
                          BtsClean = value;
                        });
                      },
                    ),
                  ],
                ),
                new Row(
                  children: <Widget>[
                    new Text("38. AC Status / تنظيف التباريد:"),
                  ],
                ),
                Column(
                  children: <Widget>[
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('OK'),
                      value: "OK",
                      groupValue: ACStatus,
                      onChanged: (value) {
                        setState(() {
                          ACStatus = value;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('NOK'),
                      value: "NOK",
                      groupValue: ACStatus,
                      onChanged: (value) {
                        setState(() {
                          ACStatus = value;
                        });
                      },
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                ),
                Column(
                  children: <Widget>[
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('OK'),
                      value: "OK",
                      groupValue: SPUsedStatus,
                      onChanged: (value) {
                        setState(() {
                          SPUsedStatus = value;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('NOK'),
                      value: "NOK",
                      groupValue: SPUsedStatus,
                      onChanged: (value) {
                        setState(() {
                          SPUsedStatus = value;
                        });
                      },
                    ),
                  ],
                ),
                new Row(
                  children: <Widget>[
                    new Text("38.Site Owner / مالك الموقع:"),
                    new Text(
                      "*",
                      style: TextStyle(color: Colors.red),
                    )
                  ],
                ),
                Column(
                  children: <Widget>[
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('Available / موجود'),
                      value: "Available / موجود",
                      groupValue: _gen2Oileak,
                      onChanged: (value) {
                        setState(() {
                          _gen2Oileak = value;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('Unavailable / غير موجود'),
                      value: "Unavailable / غير موجود",
                      groupValue: _gen2Oileak,
                      onChanged: (value) {
                        setState(() {
                          _gen2Oileak = value;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      activeColor: Colors.orange,
                      title: const Text('Prevent Enter / يمنع دخول الموظفين'),
                      value: "Prevent Enter / يمنع دخول الموظفين",
                      groupValue: _gen2Oileak,
                      onChanged: (value) {
                        setState(() {
                          _gen2Oileak = value;
                        });
                      },
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: new Row(
                    children: <Widget>[
                      new Text("39. Team Members Names / أسماء اعضاء الفريق :"),
                    ],
                  ),
                ),
                StreamBuilder<QuerySnapshot>(
                  stream: Firestore.instance.collection("FuelList").snapshots(),
                  builder: (context, snapshot) {
                    if (!snapshot.hasData) {
                      Text("Loding...");
                    } else {
                      List<DropdownMenuItem> TeamItems = [];
                      for (int i = 0; i < snapshot.data.documents.length; i++) {
                        DocumentSnapshot snap = snapshot.data.documents[i];
                        selectedTeamArray.add(snap.documentID);
                        TeamItems.add(DropdownMenuItem(
                          child: Text(snap.documentID),
                          value: "${snap.documentID}",
                        ));
                      }

                      return Container(
                        child: Column(
                          children: <Widget>[
                            SearchableDropdown.multiple(
                              items: TeamItems,
                              selectedItems: selectedTeam,
                              hint: Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: Text("Select Fuel Matrials Used"),
                              ),
                              searchHint: "Select Fuel Matrials Used",
                              onChanged: (value) {
                                setState(() {
                                  selectedTeam = value;
                                });
                              },
                              displayItem: (item, selected) {
                                return (Row(children: [
                                  selected
                                      ? Icon(
                                          Icons.check,
                                          color: Colors.orange,
                                        )
                                      : Icon(
                                          Icons.check_box_outline_blank,
                                          color: Colors.grey,
                                        ),
                                  SizedBox(width: 7),
                                  Expanded(
                                    child: item,
                                  ),
                                ]));
                              },
                              selectedValueWidgetFn: (item) {
                                return (Center(
                                    child: Card(
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          side: BorderSide(
                                            color: Colors.orange,
                                            width: 0.5,
                                          ),
                                        ),
                                        margin: EdgeInsets.all(12),
                                        child: Padding(
                                          padding: const EdgeInsets.all(8),
                                          child: Text(item.toString()),
                                        ))));
                              },
                              doneButton: (selectedItemsDone, doneContext) {
                                return (RaisedButton(
                                    onPressed: () {
                                      Navigator.pop(doneContext);
                                      setState(() {});
                                    },
                                    child: Text("Save")));
                              },
                              closeButton: null,
                              style: TextStyle(fontStyle: FontStyle.italic),
                              searchFn: (String keyword, items) {
                                List<int> ret = List<int>();
                                if (keyword != null &&
                                    items != null &&
                                    keyword.isNotEmpty) {
                                  keyword.split(" ").forEach((k) {
                                    int i = 0;
                                    items.forEach((item) {
                                      if (k.isNotEmpty &&
                                          (item.value
                                              .toString()
                                              .toLowerCase()
                                              .contains(k.toLowerCase()))) {
                                        ret.add(i);
                                      }
                                      i++;
                                    });
                                  });
                                }
                                if (keyword.isEmpty) {
                                  ret = Iterable<int>.generate(items.length)
                                      .toList();
                                }
                                return (ret);
                              },
                              clearIcon: Icon(Icons.delete),
                              icon: Icon(Icons.arrow_drop_down_circle),
                              underline: Container(
                                height: 1.0,
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(
                                            color: Colors.orange, width: 3.0))),
                              ),
                              iconDisabledColor: Colors.red,
                              iconEnabledColor: Colors.orange,
                              isExpanded: true,
                            ),
                          ],
                        ),
                      );
                    }
                    return Container();
                  },
                ),
                new TextFormField(
                  controller: _Notes,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    labelText: '40.Notes / الملاحظات:',
                    hintText: 'enter Your Answer ',
                  ),
                ),
                new Padding(
                  padding: new EdgeInsets.all(20.0),
                ),
                new RaisedButton(
                  onPressed: () {

                      checkNull();

                  },
                  child: new Text(
                    'Submit',
                    style: TextStyle(color: Colors.black),
                  ),
                  color: Colors.orange,
                ),
              ],
            ),
          ),
        ),
      ),
    ];
    final _kTabs = <Tab>[
      Tab(
        text: 'Site Info',
      ),
      Tab(text: 'Gen. 1'),
      Tab(text: 'Gen. 2'),
      Tab(text: 'Other Info'),
    ];
    return DefaultTabController(
      length: _kTabs.length,
      child: Scaffold(
        appBar: AppBar(
          actions: <Widget>[
            IconButton(
              icon: Icon(
                Icons.exit_to_app,
                color: Colors.black,
              ),
              onPressed: signOut,
            )
          ],
          title: Text(
            'BEECABLE O&M Department Sites PLM and CM Form ',
            style: TextStyle(color: Colors.black, fontSize: 14.0),
          ),
          backgroundColor: Colors.orange,
          // If TabController controller is not provided, then a
          // DefaultTabController ancestor must be provided instead.
          // Another way is to use a self-defined controller, c.f. "Bottom tab
          // bar" example.
          bottom: TabBar(
            tabs: _kTabs,
          ),
        ),
        body: TabBarView(
          children: _kTabPages,
        ),
      ),
    );
  }
}
