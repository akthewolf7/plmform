#include "window_configuration.h"

const char *kFlutterWindowTitle = "plm_form";
const unsigned int kFlutterWindowWidth = 800;
const unsigned int kFlutterWindowHeight = 600;
